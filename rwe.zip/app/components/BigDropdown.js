import React from 'react'

const BigDropdown = ({text, content}) => {
  return (
    <div>BigDropdown</div>
  )
}

export default BigDropdown